import React from 'react'

export default function Message({children}) {
  return (
    <div className={' alert alert-5 {variant}'}>{children}</div>);
}



















{/*import React from 'react'

export default function Message({variant,children}) {
  return <div className={'alert alert-$ {variant}'}>
        {children}
    </div>
  
}
*/}